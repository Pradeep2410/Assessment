# -FastAPI-backend-with-Frontend-using-Jinja-templates
Create one FastAPI backend with Frontend using Jinja templates (on root endpoint). Where users can upload a csv. And map the Name and Age column on frontend (select which row in csv contains name/age). 
